import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';

const GUIDE_FILE = path.join(process.cwd(), 'assets', 'guia-ferias-vip-natal-rn.pdf');
const GUIDE_NAME = 'guia-ferias-vip-natal-rn.pdf';
const RESEND_URL = 'https://api.resend.com/emails';
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const requestsByIp = new Map();

function reply(res, status, body) {
  return res.status(status).setHeader('Cache-Control', 'no-store').json(body);
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, (c) => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  })[c]);
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return reply(res, 405, { accepted: false, error: 'method_not_allowed' });
  }

  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.RESEND_FROM_EMAIL;
  const siteOrigin = process.env.NATAL_SITE_ORIGIN;
  if (!apiKey || !from || !siteOrigin) {
    return reply(res, 503, { accepted: false, error: 'email_service_not_configured' });
  }

  let origin;
  try { origin = new URL(siteOrigin); } catch {
    return reply(res, 500, { accepted: false, error: 'invalid_site_origin' });
  }
  if (origin.protocol !== 'https:') {
    return reply(res, 500, { accepted: false, error: 'https_required' });
  }
  const requestOrigin = req.headers.origin;
  if (requestOrigin && requestOrigin !== origin.origin) {
    return reply(res, 403, { accepted: false, error: 'origin_not_allowed' });
  }

  const body = req.body && typeof req.body === 'object' ? req.body : {};
  // Honeypot: acknowledge silently without sending email to automated spam submissions.
  if (typeof body.website === 'string' && body.website.trim()) {
    return reply(res, 200, { accepted: true });
  }
  const name = typeof body.name === 'string' ? body.name.trim().slice(0, 120) : '';
  const email = typeof body.email === 'string' ? body.email.trim().slice(0, 254) : '';
  if (!name || !EMAIL_RE.test(email)) {
    return reply(res, 400, { accepted: false, error: 'invalid_name_or_email' });
  }

  // Lightweight per-instance guard; production deployments should also enable provider/WAF limits.
  const ip = String(req.headers['x-forwarded-for'] || req.socket?.remoteAddress || 'unknown').split(',')[0].trim();
  const now = Date.now();
  for (const [key, value] of requestsByIp) if (now - value > 60 * 60 * 1000) requestsByIp.delete(key);
  const last = requestsByIp.get(ip) || 0;
  if (now - last < 60 * 1000) {
    return reply(res, 429, { accepted: false, error: 'please_wait_before_retrying' });
  }

  let pdf;
  try { pdf = await readFile(GUIDE_FILE); } catch {
    return reply(res, 500, { accepted: false, error: 'guide_file_missing' });
  }

  const downloadUrl = `${origin.origin}/assets/${GUIDE_NAME}`;
  const safeName = escapeHtml(name);
  const requestId = typeof body.requestId === 'string' && /^[A-Za-z0-9._:-]{8,120}$/.test(body.requestId) ? body.requestId : randomUUID();
  const message = {
    from,
    to: [email],
    subject: 'Seu Guia VIP de Férias em Natal',
    html: `<div style="font-family:Arial,sans-serif;color:#06122b;line-height:1.6;max-width:600px;margin:auto"><h1 style="color:#06122b">Olá, ${safeName}!</h1><p>Como pediu, enviamos em anexo o Guia VIP de Férias em Natal.</p><p>Você também pode <a href="${downloadUrl}">baixar o guia por este link</a>.</p><p>Boa viagem!<br><strong>Natal Vip Turismo</strong></p><hr><p style="font-size:12px;color:#53627c">Este e-mail é o envio do guia que você solicitou no site.</p></div>`,
    text: `Olá, ${name}!\n\nComo pediu, enviamos em anexo o Guia VIP de Férias em Natal. Você também pode baixar o guia por este link: ${downloadUrl}\n\nBoa viagem!\nNatal Vip Turismo\n\nEste e-mail é o envio do guia que você solicitou no site.`,
    attachments: [{ filename: GUIDE_NAME, content: pdf.toString('base64') }],
  };

  try {
    const providerResponse = await fetch(RESEND_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
        'Idempotency-Key': `guide-${requestId}`,
      },
      body: JSON.stringify(message),
    });
    const providerBody = await providerResponse.json().catch(() => ({}));
    if (!providerResponse.ok || !providerBody.id) {
      console.error('Guide email provider rejected request:', providerResponse.status, providerBody?.message || providerBody?.name || 'unknown');
      return reply(res, 502, { accepted: false, error: 'email_provider_rejected_request' });
    }
    requestsByIp.set(ip, now);
    return reply(res, 200, { accepted: true, emailId: providerBody.id, downloadUrl });
  } catch (error) {
    console.error('Guide email provider request failed:', error?.message || 'unknown');
    return reply(res, 502, { accepted: false, error: 'email_provider_unavailable' });
  }
}
